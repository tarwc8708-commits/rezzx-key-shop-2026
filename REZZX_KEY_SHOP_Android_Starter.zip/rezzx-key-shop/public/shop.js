const root = document.querySelector("#products");
const statusBox = document.querySelector("#status");
const money = n => (n/100).toLocaleString("th-TH",{style:"currency",currency:"THB"});
async function load(){
 try{
  const products=await (await fetch("/api/products")).json();
  root.innerHTML="";
  products.forEach(p=>{
   const card=document.createElement("article");card.className="card";
   const h=document.createElement("h3");h.textContent=p.name;
   const d=document.createElement("p");d.className="muted";d.textContent=p.description||"คีย์ดิจิทัล";
   const price=document.createElement("div");price.className="price";price.textContent=money(p.price);
   const email=document.createElement("input");email.type="email";email.placeholder="อีเมลสำหรับรับสินค้า";
   const btn=document.createElement("button");btn.textContent="สั่งซื้อ";
   btn.onclick=async()=>{
    if(!email.value){statusBox.textContent="กรุณากรอกอีเมล";return}
    btn.disabled=true;statusBox.textContent="กำลังสร้างรายการ...";
    try{
     const r=await fetch("/api/checkout",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({productId:p.id,email:email.value})});
     const data=await r.json();if(!r.ok)throw new Error(data.error||"เกิดข้อผิดพลาด");
     if(data.url)location.href=data.url;else statusBox.textContent=data.message+" เลขคำสั่งซื้อ: "+data.orderId;
    }catch(e){statusBox.textContent=e.message;btn.disabled=false}
   };
   card.append(h,d,price,email,btn);root.append(card);
  });
  if(!products.length)root.textContent="ยังไม่มีสินค้า";
 }catch(e){root.textContent="โหลดสินค้าไม่สำเร็จ"}
}
if(new URLSearchParams(location.search).has("paid"))statusBox.textContent="รับแจ้งการชำระเงินแล้ว ระบบกำลังตรวจสอบและจัดส่งคีย์";
if(new URLSearchParams(location.search).has("cancelled"))statusBox.textContent="ยกเลิกรายการชำระเงินแล้ว";
load();
