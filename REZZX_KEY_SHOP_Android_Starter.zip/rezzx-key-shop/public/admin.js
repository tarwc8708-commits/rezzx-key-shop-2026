const $=id=>document.getElementById(id), msg=t=>$("msg").textContent=t;
async function api(url,body){
 const r=await fetch(url,{method:body?"POST":"GET",headers:{"Content-Type":"application/json"},body:body?JSON.stringify(body):undefined});
 const d=await r.json();if(!r.ok)throw Error(d.error||"เกิดข้อผิดพลาด");return d;
}
async function refresh(){
 const d=await api("/api/admin/summary");$("summary").textContent=JSON.stringify({products:d.products,stock:d.stock},null,2);
 $("orders").textContent=JSON.stringify(d.orders,null,2);$("productSelect").innerHTML="";
 d.products.forEach(p=>{const o=document.createElement("option");o.value=p.id;o.textContent=p.name;$("productSelect").append(o)});
}
$("loginBtn").onclick=async()=>{try{await api("/api/admin/login",{username:$("username").value,password:$("password").value});$("login").hidden=true;$("dashboard").hidden=false;await refresh();msg("เข้าสู่ระบบแล้ว")}catch(e){msg(e.message)}};
$("addProduct").onclick=async()=>{try{await api("/api/admin/products",{name:$("pname").value,description:$("pdesc").value,price:$("pprice").value});msg("เพิ่มสินค้าแล้ว");await refresh()}catch(e){msg(e.message)}};
$("addKeys").onclick=async()=>{try{const keys=$("keys").value.split(/\r?\n/).map(x=>x.trim()).filter(Boolean);const d=await api("/api/admin/keys",{productId:$("productSelect").value,keys});msg("เพิ่มคีย์ "+d.added+" รายการแล้ว");$("keys").value="";await refresh()}catch(e){msg(e.message)}};
$("refresh").onclick=()=>refresh().catch(e=>msg(e.message));
$("logout").onclick=async()=>{try{await api("/api/admin/logout",{});location.reload()}catch(e){msg(e.message)}};
