require("dotenv").config();
const express = require("express");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const bcrypt = require("bcryptjs");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const Stripe = require("stripe");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const BASE_URL = process.env.BASE_URL || `http://localhost:${PORT}`;
const DATA_FILE = path.join(__dirname, "data.json");
const stripe = process.env.STRIPE_SECRET_KEY
  ? new Stripe(process.env.STRIPE_SECRET_KEY)
  : null;

if (!process.env.SESSION_SECRET || !process.env.ADMIN_PASSWORD) {
  console.error("ตั้งค่า SESSION_SECRET และ ADMIN_PASSWORD ใน .env ก่อน");
  process.exit(1);
}

function loadDb() {
  if (!fs.existsSync(DATA_FILE)) {
    const initial = {
      products: [
        { id: "basic", name: "REZZX BASIC", description: "แพ็กเกจเริ่มต้น", price: 4900, active: true },
        { id: "pro", name: "REZZX PRO", description: "แพ็กเกจ Pro", price: 9900, active: true },
        { id: "vip", name: "REZZX VIP", description: "แพ็กเกจ VIP", price: 19900, active: true }
      ],
      keys: [],
      orders: [],
      adminHash: bcrypt.hashSync(process.env.ADMIN_PASSWORD, 12)
    };
    fs.writeFileSync(DATA_FILE, JSON.stringify(initial, null, 2), { mode: 0o600 });
  }
  return JSON.parse(fs.readFileSync(DATA_FILE, "utf8"));
}
let db = loadDb();
function saveDb() {
  const temp = DATA_FILE + ".tmp";
  fs.writeFileSync(temp, JSON.stringify(db, null, 2), { mode: 0o600 });
  fs.renameSync(temp, DATA_FILE);
}
const sessions = new Map();
const COOKIE = "rezzx_admin";
function newToken() { return crypto.randomBytes(32).toString("hex"); }
function adminOnly(req, res, next) {
  const token = req.headers.cookie?.split(";").map(x => x.trim())
    .find(x => x.startsWith(COOKIE + "="))?.slice(COOKIE.length + 1);
  if (!token || !sessions.has(token)) return res.status(401).json({ error: "กรุณาเข้าสู่ระบบแอดมิน" });
  req.adminToken = token;
  next();
}

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.static(path.join(__dirname, "public")));
app.post("/webhook/stripe", express.raw({ type: "application/json" }), (req, res) => {
  if (!stripe || !process.env.STRIPE_WEBHOOK_SECRET) return res.sendStatus(400);
  let event;
  try {
    event = stripe.webhooks.constructEvent(req.body, req.headers["stripe-signature"], process.env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }
  if (event.type === "checkout.session.completed") {
    const session = event.data.object;
    const order = db.orders.find(o => o.id === session.metadata?.orderId);
    if (order && order.status !== "paid") {
      order.status = "paid";
      order.paidAt = new Date().toISOString();
      const key = db.keys.find(k => k.productId === order.productId && !k.sold);
      if (key) {
        key.sold = true;
        order.deliveredKey = key.value;
      } else {
        order.deliveryStatus = "รอแอดมินเติมสต็อก";
      }
      saveDb();
    }
  }
  res.json({ received: true });
});
app.use(express.json({ limit: "30kb" }));
app.use("/api/admin", rateLimit({ windowMs: 15 * 60 * 1000, limit: 30 }));

app.get("/api/products", (req, res) => {
  res.json(db.products.filter(p => p.active).map(({ id, name, description, price }) => ({ id, name, description, price })));
});

app.post("/api/checkout", rateLimit({ windowMs: 10 * 60 * 1000, limit: 10 }), async (req, res) => {
  const { productId, email } = req.body || {};
  const product = db.products.find(p => p.id === productId && p.active);
  if (!product) return res.status(404).json({ error: "ไม่พบสินค้า" });
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ error: "กรอกอีเมลให้ถูกต้อง" });
  const order = {
    id: crypto.randomUUID(), productId, productName: product.name,
    amount: product.price, email, status: "pending",
    createdAt: new Date().toISOString()
  };
  db.orders.push(order);
  saveDb();

  if (!stripe) {
    return res.json({ mode: "demo", message: "ร้านยังไม่ได้ตั้งค่าเกตเวย์เงินจริง กรุณาติดต่อแอดมินเพื่อชำระเงินแบบทดสอบ", orderId: order.id });
  }
  try {
    const session = await stripe.checkout.sessions.create({
      mode: "payment",
      customer_email: email,
      line_items: [{
        quantity: 1,
        price_data: {
          currency: "thb",
          unit_amount: product.price,
          product_data: { name: product.name, description: product.description }
        }
      }],
      success_url: `${BASE_URL}/?paid=1&order=${order.id}`,
      cancel_url: `${BASE_URL}/?cancelled=1`,
      metadata: { orderId: order.id }
    });
    order.checkoutSessionId = session.id;
    saveDb();
    res.json({ mode: "gateway", url: session.url });
  } catch (err) {
    console.error(err);
    res.status(502).json({ error: "สร้างรายการชำระเงินไม่สำเร็จ" });
  }
});

app.post("/api/admin/login", rateLimit({ windowMs: 15 * 60 * 1000, limit: 8 }), (req, res) => {
  const { username, password } = req.body || {};
  if (username !== process.env.ADMIN_USERNAME || !bcrypt.compareSync(password || "", db.adminHash)) {
    return res.status(401).json({ error: "ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง" });
  }
  const token = newToken();
  sessions.set(token, true);
  res.setHeader("Set-Cookie", `${COOKIE}=${token}; HttpOnly; SameSite=Strict; Path=/; Secure`);
  res.json({ ok: true });
});
app.post("/api/admin/logout", adminOnly, (req, res) => {
  sessions.delete(req.adminToken);
  res.setHeader("Set-Cookie", `${COOKIE}=; HttpOnly; SameSite=Strict; Path=/; Secure; Max-Age=0`);
  res.json({ ok: true });
});
app.get("/api/admin/summary", adminOnly, (req, res) => {
  res.json({
    products: db.products,
    stock: db.products.map(p => ({ productId: p.id, count: db.keys.filter(k => k.productId === p.id && !k.sold).length })),
    orders: db.orders.map(({ deliveredKey, ...o }) => o)
  });
});
app.post("/api/admin/products", adminOnly, (req, res) => {
  const { name, description, price } = req.body || {};
  const cents = Math.round(Number(price) * 100);
  if (!name || !Number.isFinite(cents) || cents < 100) return res.status(400).json({ error: "กรอกชื่อและราคาให้ถูกต้อง (ขั้นต่ำ 1 บาท)" });
  const id = crypto.randomBytes(6).toString("hex");
  db.products.push({ id, name: String(name).slice(0, 60), description: String(description || "").slice(0, 160), price: cents, active: true });
  saveDb(); res.json({ ok: true, id });
});
app.post("/api/admin/keys", adminOnly, (req, res) => {
  const { productId, keys } = req.body || {};
  if (!db.products.some(p => p.id === productId) || !Array.isArray(keys) || !keys.length || keys.length > 100) {
    return res.status(400).json({ error: "เลือกสินค้าและใส่คีย์ 1-100 รายการ" });
  }
  const clean = keys.map(k => String(k).trim()).filter(k => k && k.length <= 200);
  clean.forEach(value => db.keys.push({ id: crypto.randomUUID(), productId, value, sold: false }));
  saveDb(); res.json({ ok: true, added: clean.length });
});
app.get("/api/admin/orders", adminOnly, (req, res) => res.json(db.orders));

app.listen(PORT, "0.0.0.0", () => console.log(`REZZX KEY SHOP running at ${BASE_URL}`));
